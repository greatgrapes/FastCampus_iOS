//
//  layout.swift
//  WarmUp
//
//  Created by beaunexMacBook on 12/8/23.
//

import SwiftUI

struct Layout: View {
    var body: some View {
        VStack {
            Image(systemName: "pencil")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .padding()
            
            MyText(subject: "Text Element 1")
            
            MyText(subject: "Text Element 2")
            
            MyText(subject: "Text Element 3")
  
            HStack {
                MyButton(buttonTitle: "Button 1", buttonColor: .gray)
                MyButton(buttonTitle: "Button 2", buttonColor: .blue)
            }
            Button {
                
            } label: {
                VStack {
                    Image(systemName: "arrow.right.circle.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50)
                    Text("Complex Button")
                }
                .foregroundColor(.white)
                .padding()
                .background(.orange)
                .cornerRadius(10)
               
            }
        }
    }
}

#Preview {
    Layout()
}
