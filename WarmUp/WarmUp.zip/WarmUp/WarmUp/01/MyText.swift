//
//  MyText.swift
//  WarmUp
//
//  Created by beaunexMacBook on 12/8/23.
//

import SwiftUI

struct MyText: View {
    var subject: String
    
    var body: some View {
        Text(subject)
            .font(.body)
            .padding()
    }
}

#Preview {
    MyText(subject: "")
}
