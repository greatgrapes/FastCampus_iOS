//
//  Onboarding.swift
//  WarmUp
//
//  Created by beaunexMacBook on 12/8/23.
//

import SwiftUI

struct Onboarding: View {
    var body: some View {
        VStack {
            Text("What`s New in Photos.")
                .font(.system(size: 30))
                .bold()
                .padding()
                .padding(.top, 50)
            
            HStack {
                Image(systemName: "person.2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 35)
                    .padding(.horizontal, 7)
                    .foregroundColor(.blue)
                VStack(alignment: .leading) {
                    Text("Shared Library")
                        .font(.headline)
                    Text("Combine photos and videos with the people Combine photos and videos with the people Combine photos and videos with the people")
                }
                .padding(.trailing)
            }
            
            HStack {
                Image(systemName: "doc.on.doc")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30)
                    .padding(.horizontal, 7)
                    .foregroundColor(.blue)
                
                VStack(alignment: .leading) {
                    Text("Copy & Paste Edits")
                        .font(.headline)
                    Text("Combine photos and videos with the people Combine photos and videos with the people Combine photos and videos with the people")
                }
                .padding(.trailing)
            }
            
            HStack {
                Image(systemName: "sparkles.square.fill.on.square")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 35)
                    .padding(.horizontal, 7)
                    .foregroundColor(.blue)
                VStack(alignment: .leading) {
                    Text("Merge Duplicates")
                        .font(.headline)
                    Text("Combine photos and videos with the people Combine photos and videos with the people Combine photos and videos with the people")
                }
                .padding(.trailing)
            }
            .padding(.vertical)
            Spacer()
            Button{
                
            }label: {
                Text("Continue")
                // 화면 꽉 차도록 .maxWidth
                    .padding()
                //                    .frame(maxWidth: .infinity)
                    .frame(width: 350)
                    .background(.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding(.bottom, 50)
        }
        
    }
}

#Preview {
    Onboarding()
}
