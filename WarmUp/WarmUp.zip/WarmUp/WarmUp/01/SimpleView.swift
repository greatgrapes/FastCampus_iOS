//
//  SimpleView.swift
//  WarmUp
//
//  Created by beaunexMacBook on 12/8/23.
//

import SwiftUI

struct SimpleView: View {
    var body: some View {
        VStack {
            Image(systemName: "pencil.line")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
            
            Text("헤드라인 입니다")
                .font(.headline)
                .bold()
                //패딩 컨텐츠의 여백
                .padding()
            
            Text("서브헤드라인 입니다.")
                .font(.subheadline)
                .padding()
            
            Text("바디 입니다")
                .font(.body)
                .padding()
            
            Button {
                //
            } label: {
                Text("Click Me")
                    .padding()
                    .background(.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .bold()
            }
        }
    }
}

#Preview {
    SimpleView()
}


/*
전후 관계가 상관 있는 애들이 있고, 상관 없는 애들이 있음.(신경 써서 코드쓰기)
Modifier의 순서는 중요함.
많이 해보시면 됩니당.
많이 따라치시고, 많이 고민하고, 손이 익고, 기억함.
자연스럽게 생각이 들 때 까지.
*/
