//
//  WarmUpApp.swift
//  WarmUp
//
//  Created by beaunexMacBook on 12/8/23.
//

import SwiftUI

@main
struct WarmUpApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
